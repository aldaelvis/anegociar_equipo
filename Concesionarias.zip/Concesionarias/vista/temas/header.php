<?php
if (($_GET["action"] == "inicio") OR ($_GET["action"] == "ver_clasificado")) {
    ?>

    <?php
} else {

}
#}
?>