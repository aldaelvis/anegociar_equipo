<div id="contenido-empleos">
	<!--<h1>maquinarias</h1>-->
	<div class="vista-maquinarias">
		<?php

		$vistaUsuario = new GestorAnunciosController();
		$vistaUsuario -> mostrarClasificadosMotosController();

		?>
	</div>
</div>