<div id="content">
	<h1>gALERIA PRINCIPAL</h1>
	<!--START Juicebox EMBED.-->
	<script src="vista/modulos/galeria/jbcore/juicebox.js"></script>

	<script type="text/javascript">
	new juicebox({
		configUrl: 'vista/modulos/galeria/ver_clasificado.php',
		containerid:'juicebox-container',
		// baseURL:'../full/',
		backgroundColor:'rgba(0,0,0,.9)',
		galleryHeight:'600',
		galleryWidth:'708'
	});
	</script>
	<div id="juicebox-container"></div>
	<!-- END Juicebox EMBED -->
</div>