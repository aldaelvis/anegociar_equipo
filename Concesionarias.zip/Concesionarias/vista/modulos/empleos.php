<div id="contenido-empleos">
	<!--<h1>empleos</h1>-->
	<?php

	$vistaUsuario = new GestorAnunciosController();
	$vistaUsuario -> mostrarClasificadosEmpleosController();

	?>
</div>