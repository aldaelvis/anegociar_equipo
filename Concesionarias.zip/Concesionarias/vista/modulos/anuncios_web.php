<div id="bloque-bienvenida">
	<h1>agentes</h1>
</div>

<div id="bloque-elije-tipo-clasificado">
    <div class="bloque-elije-tipo-clasificado">
        <div class="elije-tipo-anuncio">
        <h1>Seleccione una Sección:</h1>
            <div class="categoria">
                <div class="imagen-tipo-anuncio">
                    <!-- 
                        <a href="index.php?action=elije_plan_anuncio&cat=vehiculos" name="tab1" value="elje-tipo-anuncio">
                        <img src="vista\temas\img\publicacion-vehiculos.png" alt="Icon" class="img-responsive">
                        </a>
                     -->
                    <form action="elije_plan_anuncio" method="post">
                        <button type="submit" name="cat" value="vehiculos" class="btn-link">
                            <img src="vista\temas\img\publicacion-vehiculos.png" alt="Icon" class="img-responsive">
                        </button>
                    </form>
                </div>
                <div class="titulo-tipo-anuncio">
                <!-- <h4>Vehículos</h4> -->
                    <form action="elije_plan_anuncio" method="post">
                        <button type="submit" name="cat" value="vehiculos" class="btn-link">Vender</button>
                    </form>
                    <!-- <a href="index.php?action=elije_plan_anuncio&cat=vehiculos" class="btn btn-success"><i class="fa fa-picture-o" aria-hidden="true"></i>Vender</a> -->
                </div>
            </div>
            <div class="categoria">
                <div class="imagen-tipo-anuncio">
                    <form action="elije_plan_anuncio" method="post">
                        <button type="submit" name="cat" value="motos" class="btn-link">
                            <img src="vista\temas\img\publicacion-motos.png" alt="Icon" class="img-responsive">
                        </button>
                    </form>
                </div>
                <div class="titulo-tipo-anuncio">
                <!-- <h4>Motos</h4> -->
                    <form action="elije_plan_anuncio" method="post">
                        <button type="submit" name="cat" value="motos" class="btn-link">Vender</button>
                    </form>
                </div>
            </div>
            <div class="categoria">
                <div class="imagen-tipo-anuncio">
                    <form action="elije_plan_anuncio" method="post">
                        <button type="submit" name="cat" value="inmuebles" class="btn-link">
                            <img src="vista\temas\img\publicacion-inmuebles.png" alt="Icon" class="img-responsive">
                        </button>
                    </form>
                </div>
                <div class="titulo-tipo-anuncio">
                <!-- <h4>Inmuebles</h4> -->
                    <form action="elije_plan_anuncio" method="post">
                        <button type="submit" name="cat" value="inmuebles" class="btn-link">Vender</button>
                    </form>
                </div>
            </div>
            <div class="categoria">
                <div class="imagen-tipo-anuncio">
                    <form action="elije_plan_anuncio" method="post">
                        <button type="submit" name="cat" value="empleos" class="btn-link">
                            <img src="vista\temas\img\publicacion-clasificados.png" alt="Icon" class="img-responsive">
                        </button>
                    </form>
                </div>
                <div class="titulo-tipo-anuncio">
                <!-- <h4>Empleos</h4> -->
                    <form action="elije_plan_anuncio" method="post">
                        <button type="submit" name="cat" value="empleos" class="btn-link">Vender</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- <?php
    // $vistaPromoverMarcas = new GestorPlanesController();
    // $vistaPromoverMarcas -> vistaAnunciosPlanesController();
?> -->