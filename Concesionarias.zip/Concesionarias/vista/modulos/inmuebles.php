<div id="contenido-inmuebles">
	<!--<h1>Inmuebles</h1>-->
	<?php

		$vistaUsuario = new GestorAnunciosController();
		$vistaUsuario -> mostrarClasificadosInmueblesController();
	?>
</div>